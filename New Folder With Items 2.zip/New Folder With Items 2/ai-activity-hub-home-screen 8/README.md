# AI Activity Hub — Home Screen

A Next.js + Tailwind starter implementing the AI Activity Hub home dashboard in the BMW Editorial × 2027 Silicon Valley design direction.

## What is included

1. Next.js app setup
2. Tailwind config with BMW editorial tokens
3. Core components:
   - Button
   - Card / Tag
   - Sidebar
   - DataTable
   - CommandPalette
   - StatCard
4. `/app/page.tsx` composed into the AI Activity Hub Home Screen

## Run locally

```bash
npm install
npm run dev
```

Open:

```txt
http://localhost:3000
```

## Design rules

- Paper-neutral surfaces
- Ink typography
- Serif editorial headings
- Hairline borders
- Minimal 4px radius
- Subtle hover motion
- Accessible focus rings
- Reduced-motion friendly


## Added in Step 2 — Timeline Screen

New files:

```txt
/app/timeline/page.tsx
/components/timeline/activity-event-card.tsx
/components/timeline/timeline-filters.tsx
/components/timeline/timeline-states.tsx
```

Open:

```txt
http://localhost:3000/timeline
```

Includes:

- Activity event cards
- Timeline filters
- Timeline side metrics
- Loading state
- Empty state
- Error state
- Action buttons for Open, Add to Project, Extract Tasks, Archive
- Responsive main feed + side panel layout


## Added in Step 3 — Inbox Triage Screen

New files:

```txt
/app/inbox/page.tsx
/components/inbox/inbox-card.tsx
/components/inbox/inbox-tabs.tsx
/components/inbox/inbox-side-panel.tsx
/components/inbox/inbox-states.tsx
```

Open:

```txt
http://localhost:3000/inbox
```

Includes:

- Inbox triage cards
- Detected decisions/tasks/artifacts
- Suggested project panel
- Triage actions
- Inbox filter tabs
- Keyboard shortcut panel
- Loading, empty and error states


## Added in Step 4 — Artifacts Library Screen

New files:

```txt
/app/artifacts/page.tsx
/components/artifacts/artifact-card.tsx
/components/artifacts/artifact-detail-panel.tsx
/components/artifacts/artifact-table.tsx
/components/artifacts/artifact-states.tsx
```

Open:

```txt
http://localhost:3000/artifacts
```

Includes:

- Artifact grid
- Artifact cards
- Artifact detail panel
- Artifact table
- Version/source/usage mini panels
- Upload/import actions
- Loading, empty and error states


## Added in Step 5 — Chat Detail Screen

New files:

```txt
/app/chats/page.tsx
/components/chat/chat-summary-panel.tsx
/components/chat/extracted-items.tsx
/components/chat/transcript.tsx
/components/chat/related-work.tsx
/components/chat/chat-states.tsx
```

Open:

```txt
http://localhost:3000/chats
```

Includes:

- Chat header metadata
- AI summary panel
- Extracted tasks, decisions and artifacts
- Full transcript layout
- Related work panel
- Loading, empty and error states


## Added in Step 6 — Projects System

New files:

```txt
/app/projects/page.tsx
/app/projects/[id]/page.tsx
/components/projects/project-card.tsx
/components/projects/project-overview.tsx
/components/projects/project-tabs.tsx
/components/projects/project-lists.tsx
/components/projects/project-states.tsx
/lib/projects-data.ts
```

Open:

```txt
http://localhost:3000/projects
http://localhost:3000/projects/personal-ai-dashboard
```

Includes:

- Projects list
- Project cards
- Project detail page
- Project overview metrics
- Project tabs
- Recent activity
- Project artifacts
- Project chats
- Project tasks
- Project decisions
- Project state components


## Added in Step 6 Full + Step 7 Search

Step 6 fully enhanced:
```txt
/components/projects/project-sidebar.tsx
```

Step 7 Search added:
```txt
/app/search/page.tsx
/components/search/search-result-card.tsx
/components/search/search-filters.tsx
/components/search/ask-ai-panel.tsx
/components/search/search-states.tsx
```

Open:
```txt
http://localhost:3000/projects
http://localhost:3000/projects/personal-ai-dashboard
http://localhost:3000/search
```

Includes:
- Project metadata/governance sidebar
- Universal search page
- Ask AI panel
- Search filters
- Source-linked result cards
- Search loading, empty and error states


## Added in Step 8 — Full Command Layer

New files:

```txt
/app/command/page.tsx
/components/command/command-types.ts
/components/command/command-data.tsx
/components/command/command-dialog.tsx
/components/command/use-command-shortcut.ts
/components/command/global-command-provider.tsx
```

Updated:

```txt
/components/ui/command-palette.tsx
/components/ui/sidebar.tsx
```

Open:

```txt
http://localhost:3000/command
```

Capabilities:

- Cmd/Ctrl+K global trigger
- Typeahead filtering
- Grouped commands: Navigation, Actions, Search, AI
- Keyboard navigation: Arrow Up/Down
- Enter to execute
- Escape to close
- Click outside to close
- Focus return after close
- Empty state
- Preview panel
- Source-linked navigation commands
