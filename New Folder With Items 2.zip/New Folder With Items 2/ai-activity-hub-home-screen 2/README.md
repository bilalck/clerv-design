# AI Activity Hub — Home Screen

A Next.js + Tailwind starter implementing the AI Activity Hub home dashboard in the BMW Editorial × 2027 Silicon Valley design direction.

## What is included

1. Next.js app setup
2. Tailwind config with BMW editorial tokens
3. Core components:
   - Button
   - Card / Tag
   - Sidebar
   - DataTable
   - CommandPalette
   - StatCard
4. `/app/page.tsx` composed into the AI Activity Hub Home Screen

## Run locally

```bash
npm install
npm run dev
```

Open:

```txt
http://localhost:3000
```

## Design rules

- Paper-neutral surfaces
- Ink typography
- Serif editorial headings
- Hairline borders
- Minimal 4px radius
- Subtle hover motion
- Accessible focus rings
- Reduced-motion friendly
