"use client";

import * as React from "react";
import { Search } from "lucide-react";
import { Button } from "@/components/ui/button";

export function CommandPalette() {
  const [open, setOpen] = React.useState(false);

  React.useEffect(() => {
    function onKeyDown(event: KeyboardEvent) {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setOpen(true);
      }
      if (event.key === "Escape") {
        setOpen(false);
      }
    }

    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="grid min-h-11 w-full max-w-xl grid-cols-[20px_1fr_auto] items-center gap-3 border border-line-hair bg-paper-50 px-4 text-left text-sm text-[var(--grey-600)] transition duration-150 hover:border-line-medium"
        aria-haspopup="dialog"
      >
        <Search aria-hidden="true" className="h-4 w-4" />
        <span>Search all AI work…</span>
        <span className="text-[11px] uppercase tracking-[0.14em] text-[var(--grey-500)]">⌘K</span>
      </button>

      {open ? (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="command-title"
          className="fixed inset-0 z-50 grid place-items-start justify-center bg-black/25 px-4 pt-[10vh]"
        >
          <div className="w-[min(720px,100%)] rounded-[var(--radius-3)] border border-line-hair bg-paper-0 p-5 shadow-float">
            <div className="flex items-center justify-between gap-4">
              <h2 id="command-title" className="font-serif text-2xl uppercase">
                Command Palette
              </h2>
              <Button variant="ghost" onClick={() => setOpen(false)}>
                Close
              </Button>
            </div>
            <input
              autoFocus
              placeholder="Search chats, artifacts, decisions, projects…"
              className="mt-5 w-full border-0 border-b border-line-strong bg-transparent py-4 text-lg outline-none focus:border-ink"
            />
            <div className="mt-4 divide-y divide-line-hair">
              {["Review inbox", "Open timeline", "Import ChatGPT export", "Create project"].map((item) => (
                <button
                  key={item}
                  type="button"
                  className="grid w-full grid-cols-[48px_1fr] gap-4 py-3 text-left transition duration-150 hover:bg-paper-50"
                  onClick={() => setOpen(false)}
                >
                  <span className="grid h-8 w-8 place-items-center border border-line-medium text-xs">⌘</span>
                  <span>{item}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
