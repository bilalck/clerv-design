# AI Activity Hub — Home Screen

A Next.js + Tailwind starter implementing the AI Activity Hub home dashboard in the BMW Editorial × 2027 Silicon Valley design direction.

## What is included

1. Next.js app setup
2. Tailwind config with BMW editorial tokens
3. Core components:
   - Button
   - Card / Tag
   - Sidebar
   - DataTable
   - CommandPalette
   - StatCard
4. `/app/page.tsx` composed into the AI Activity Hub Home Screen

## Run locally

```bash
npm install
npm run dev
```

Open:

```txt
http://localhost:3000
```

## Design rules

- Paper-neutral surfaces
- Ink typography
- Serif editorial headings
- Hairline borders
- Minimal 4px radius
- Subtle hover motion
- Accessible focus rings
- Reduced-motion friendly


## Added in Step 2 — Timeline Screen

New files:

```txt
/app/timeline/page.tsx
/components/timeline/activity-event-card.tsx
/components/timeline/timeline-filters.tsx
/components/timeline/timeline-states.tsx
```

Open:

```txt
http://localhost:3000/timeline
```

Includes:

- Activity event cards
- Timeline filters
- Timeline side metrics
- Loading state
- Empty state
- Error state
- Action buttons for Open, Add to Project, Extract Tasks, Archive
- Responsive main feed + side panel layout


## Added in Step 3 — Inbox Triage Screen

New files:

```txt
/app/inbox/page.tsx
/components/inbox/inbox-card.tsx
/components/inbox/inbox-tabs.tsx
/components/inbox/inbox-side-panel.tsx
/components/inbox/inbox-states.tsx
```

Open:

```txt
http://localhost:3000/inbox
```

Includes:

- Inbox triage cards
- Detected decisions/tasks/artifacts
- Suggested project panel
- Triage actions
- Inbox filter tabs
- Keyboard shortcut panel
- Loading, empty and error states


## Added in Step 4 — Artifacts Library Screen

New files:

```txt
/app/artifacts/page.tsx
/components/artifacts/artifact-card.tsx
/components/artifacts/artifact-detail-panel.tsx
/components/artifacts/artifact-table.tsx
/components/artifacts/artifact-states.tsx
```

Open:

```txt
http://localhost:3000/artifacts
```

Includes:

- Artifact grid
- Artifact cards
- Artifact detail panel
- Artifact table
- Version/source/usage mini panels
- Upload/import actions
- Loading, empty and error states


## Added in Step 5 — Chat Detail Screen

New files:

```txt
/app/chats/page.tsx
/components/chat/chat-summary-panel.tsx
/components/chat/extracted-items.tsx
/components/chat/transcript.tsx
/components/chat/related-work.tsx
/components/chat/chat-states.tsx
```

Open:

```txt
http://localhost:3000/chats
```

Includes:

- Chat header metadata
- AI summary panel
- Extracted tasks, decisions and artifacts
- Full transcript layout
- Related work panel
- Loading, empty and error states
