# AI Interaction Import Report

Generated: 2026-05-04T16:06:46.915216+00:00
Total records: **9**

## Counts by platform

- **claude.ai** — 2
- **chatgpt** — 2
- **replit** — 1
- **midjourney** — 1
- **bolt** — 1
- **lovable** — 1
- **v0** — 1

## Top projects (inferred)

- **Stead UI Pro** — 3 sessions
- **SimpSocial** — 2 sessions
- **DriveCentric** — 1 sessions
- **Stead Skills Library** — 1 sessions
- **InternalTool** — 1 sessions

## Cross-platform sessions detected

2 records have at least one `linked_sessions` entry. These are conversations on different platforms that started within 60 seconds and share ≥40% word overlap — i.e. the same work session spanning multiple tools.

## Dedup stats

- Input records: 9
- Removed by pass-1 dedup (same platform + native_id): 0
- Cross-platform links created: 1

## Recommended next merge

These platforms are not represented in the current timeline. If you use them, add them to close the gap:

- **cursor** — see `references/platform-export-guide.md`
- **windsurf** — see `references/platform-export-guide.md`
- **gemini** — see `references/platform-export-guide.md`
- **claude_code** — see `references/platform-export-guide.md`
